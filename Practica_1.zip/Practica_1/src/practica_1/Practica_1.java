/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica_1;

import Calculadora.Operaciones;
/**
 *
 * @author david
 */
public class Practica_1 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Operaciones casio = new Operaciones();
        
        System.out.println("Suma: " + casio.suma(15, 15));
        System.out.println("Resta: " + casio.resta(15, 15));
        System.out.println("Multiplicacion: " + casio.mult(15, 15));
        System.out.println("Division: " + casio.div(15, 15));
    }
    
    
}
