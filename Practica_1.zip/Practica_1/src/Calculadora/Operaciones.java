/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Calculadora;

/**
 *
 * @author david
 */
public class Operaciones 
{
    public int suma(int numero1, int numero2){
        return numero1 + numero2;
    }
    
    public int resta(int numero1, int numero2){
        return numero1 - numero2;
    }
    
    public int mult(int numero1, int numero2){
        return numero1 * numero2;
    }
    
    public int div(int numero1, int numero2){
        return numero1 / numero2;
    }
}
