/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica.pkg4;
import animales.*;
/**
 *
 * @author david
 */
public class Practica4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Animal a = new Animal("Electrico");
        Gato g = new Gato("pinut");
        Pajaro p = new Pajaro("Loco");
        Perro f = new Perro("Firulais");
        
        System.out.println("Animal");
        a.mostrarNombre();
        a.hacerSonido();
        System.out.println(a.comer());
      
        System.out.println("\nGato");
        g.mostrarNombre();
        System.out.println(g.comer());
        g.hacerSonido();
        
        System.out.println("\nPajaro");
        p.mostrarNombre();
        System.out.println(p.comer());
        p.hacerSonido();
        p.volar();
        
        System.out.println("\nPerro");
        f.mostrarNombre();
        System.out.println(f.comer());
        f.hacerSonido();
        System.out.println(f.jugar());
    }
    
}