package practicatres;

/**
 *
 * @author david
 */
public class CuentaBancaria 
{

    /**
     * @return the numeroCuenta
     */
    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    /**
     * @param numeroCuenta the numeroCuenta to set
     */
    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    /**
     * @return the titular
     */
    public String getTitular() {
        return titular;
    }

    /**
     * @param titular the titular to set
     */
    public void setTitular(String titular) {
        this.titular = titular;
    }

    /**
     * @return the saldo
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(double saldo) {
        if(saldo >= 0)
            this.saldo = saldo;
        else
            System.out.println("El saldo no puede ser una cantidad negativa");
    }
    
    private String numeroCuenta;
    private String titular;
    private double saldo;
    
    
    public void depositar(double monto){
        if(monto > 0)
            this.saldo += monto;
        else
            System.out.println("Monto no valido para el deposito");
    }
    
    public void retirar(double monto){
        if(monto > 0 && monto <= this.saldo)
            this.saldo -= monto;
        else
            System.out.println("Saldo insuficiente o monto no valido");
    }
    
}
