package practicatres;

/**
 *
 * @author david
 */
public class RunPractica3 {
    public static void main(String[] args) {
        // TODO code application logic here
        CuentaBancaria cuentaBanamex = new CuentaBancaria();
        cuentaBanamex.setNumeroCuenta("15789123");
        cuentaBanamex.setTitular("David García");
        cuentaBanamex.setSaldo(5000);
        
        System.out.println("Saldo inicial: " + cuentaBanamex.getSaldo());
        
        cuentaBanamex.depositar(500);
        System.out.println("Despues del deposito: " + cuentaBanamex.getSaldo());
        
        cuentaBanamex.retirar(400);
        System.out.println("Despues del retiro: " + cuentaBanamex.getSaldo());
        
        cuentaBanamex.retirar(9000);
    }
}
