/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tipos;

import Transportes.Transporte;
import Transportes.Operable;
import Excepciones.CapacidadExcedidaException;


/**
 *
 * @author david
 */
public class TransporteAereo extends Transporte implements Operable {
    
    public TransporteAereo(String id, int capacidad) {
        super(id, capacidad);
    }
    
    @Override
    public String tipo() {
        return "Transporte Aereo";
    }
    
    @Override
    public void mover() {
        System.out.println("Volando en el aire");
    }
    
    @Override
    public void realizarMantenimiento() {
        System.out.println("Realizando mantenimiento aereo: revisando el motor");
    }
}
