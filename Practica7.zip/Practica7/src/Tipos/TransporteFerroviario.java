/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tipos;

import Transportes.Transporte;
import Transportes.Operable;
import Excepciones.CapacidadExcedidaException;

/**
 *
 * @author david
 */
public class TransporteFerroviario extends Transporte implements Operable {
    
    public TransporteFerroviario(String id, int capacidad) {
        super(id, capacidad);
    }
    
    @Override
    public String tipo() {
        return "Ferroviario";
    }
    
    @Override
    public void mover() {
        System.out.println("Viajando por las vias");
    }
    
    @Override
    public void realizarMantenimiento() {
        System.out.println("Realizando mantenimiento ferroviario: revisando el motor");
    }
}
