/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tipos;

import Transportes.Transporte;
import Transportes.Operable;
import Excepciones.CapacidadExcedidaException;

/**
 *
 * @author david
 */
public class TransporteTerrestre extends Transporte implements Operable {
    
    public TransporteTerrestre(String id, int capacidad) {
        super(id, capacidad);
    }
    
    @Override
    public String tipo() {
        return "Transporte Terrestre";
    }
    
    @Override
    public void mover() {
        System.out.println("Rodando en carretera");
    }
    
    @Override
    public void realizarMantenimiento() {
        System.out.println("Realizando mantenimiento terrestre: revisando el motor");
    }
}