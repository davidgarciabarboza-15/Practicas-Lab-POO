/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica7;

import Transportes.Transporte;
import Transportes.Operable;
import Excepciones.CapacidadExcedidaException;
import Tipos.TransporteMaritimo;
import Tipos.TransporteTerrestre;
import Tipos.TransporteAereo;
import Tipos.TransporteFerroviario;
import java.util.ArrayList;

/**
 *
 * @author david
 */
public class RunPractica7 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Transporte> transportes = new ArrayList<>();
        
        transportes.add(new TransporteMaritimo("BAR-01", 100));
        transportes.add(new TransporteTerrestre("CAM-015", 50));
        transportes.add(new TransporteAereo("AV-777", 80));
        transportes.add(new TransporteFerroviario("TREN-1212", 200));
        
        for (Transporte transporte : transportes) {
            System.out.println("\n" + transporte.tipo());
            transporte.mover();
            
            try {
                transporte.transportar(60);
            } catch (CapacidadExcedidaException e) {
                System.out.println("ERROR: " + e.getMessage());
            }
            
            if (transporte instanceof Operable) {
                ((Operable) transporte).realizarMantenimiento();
            }
        }
        
        System.out.println("\nPrueba dE Excepciones\n");
        try {
            System.out.println("Transporte con capacidad 600");
            TransporteTerrestre busGrande = new TransporteTerrestre("BUS-XL", 600);
        } catch (IllegalArgumentException e) {
            System.out.println("Excepcion capturada: " + e.getMessage());
        }
        try {
            System.out.println("\nTransporte con capacidad 0");
            TransporteAereo avionVacio = new TransporteAereo("AV-000", 0);
        } catch (IllegalArgumentException e) {
            System.out.println("Excepcion capturada: " + e.getMessage());
        }
    }
}
