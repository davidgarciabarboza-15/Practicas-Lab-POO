

Este proyecto demuestra los principios de POO mediante un sistema de gestión de transportes.    
El **encapsulamiento** se implementa en "Transportes/Transporte.java" con atributos privados y  
validaciones en los setters. La **herencia** se ve en la clase abstracta "Transportes/Transporte.java"  
extendida por todas las subclases en "Tipos/", mientras que la **interface** "Transportes/Operable.java"    
define el contrato de mantenimiento implementado por cada transporte.

El **polimorfismo** se demuestra en "practice7/RunPractice7.java" mediante  
un ArrayList<Transporte> que procesa diferentes tipos uniformemente.    
Las **excepciones** incluyen la personalizada "Exceptions/CapacidadExcedidaException.java"  
y su manejo con try-catch, además de validaciones con IllegalArgumentException en los setters para capacidad inválida.