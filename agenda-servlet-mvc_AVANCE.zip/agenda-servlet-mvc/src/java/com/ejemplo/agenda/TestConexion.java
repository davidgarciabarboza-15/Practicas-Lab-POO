package com.ejemplo.agenda;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import com.ejemplo.agenda.util.DB;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author david
 */
public class TestConexion {
    public static void main(String[] args) {
        try (Connection conn = DB.getConnection()) {
            System.out.println("Conexion exitosa: " + conn);
        } catch (SQLException e) {
            System.err.println("Error de conexion: " + e.getMessage());
        }
    } 
}
