/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.agenda.web;

import com.ejemplo.agenda.dao.ContactoDAO;
import com.ejemplo.agenda.model.Contacto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author david
 */
@WebServlet("/contactos")
public class ContactoServlet extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //Aqui iria lo de mostrar la lista de contactos
        List<Contacto> contactos = null; // Todavia no lo e implementado

        request.setAttribute("contactos", contactos);
        request.getRequestDispatcher("/views/lista.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Aqui iria lo de crear un nuevo contacto
        String nombre = request.getParameter("nombre");
        String apellidoPaterno = request.getParameter("apellidoPaterno");
        String telefono = request.getParameter("telefono");
        String sexo = request.getParameter("sexo");
        String tipoContacto = request.getParameter("tipoContacto");

        Contacto nuevo = new Contacto(nombre, apellidoPaterno, telefono, sexo, tipoContacto);

        //Aqui se pondra lo de guardar el contacto
        //ContactoDAO dao = new ContactoDAOImpl(); //Esto lo tengo pendiente
        //dao.crear(nuevo);

        response.sendRedirect("contactos");
    }
}
