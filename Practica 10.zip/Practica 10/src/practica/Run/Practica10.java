/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica.Run;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author david
 */
public class Practica10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*Nombres de prueba para la practica*/
        String[] archivos = {"sucursal1.txt", "sucursal2.txt", "sucursal3.txt"};
        
        String[][] contenidos = {
            {"Ana", "Luis", "Sofia"},
            {"Carlos", "Marta", "Pedro"},
            {"Laura", "Jorge", "Diego"}
        };
        
        for (int i = 0; i < archivos.length; i++) {
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivos[i]))) {
                for (String nombre : contenidos[i]) {
                    bw.write(nombre);
                    bw.newLine();
                }
            } catch (IOException e) {
                System.err.println("Error al crear el archivo: " + archivos[i]);
                e.printStackTrace();
            }
        }
           
        Lector_de_archivo hilo1 = new Lector_de_archivo("sucursal1.txt");
        Lector_de_archivo hilo2 = new Lector_de_archivo("sucursal2.txt");
        Lector_de_archivo hilo3 = new Lector_de_archivo("sucursal3.txt");

        hilo1.setName("Hilo-1");
        hilo2.setName("Hilo-2");
        hilo3.setName("Hilo-3");

        hilo1.start();
        hilo2.start();
        hilo3.start();
    }
    
}
