/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica.Run;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
/**
 *
 * @author david
 */
public class Lector_de_archivo extends Thread{
    private String nombreArchivo;

    public Lector_de_archivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    @Override
    public void run() {
        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                System.out.println(getName() + " leyendo: " + linea);
                Thread.sleep(115);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
