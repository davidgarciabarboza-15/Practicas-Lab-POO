/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica.pkg8;
import java.util.*;
/**
 *
 * @author david
 */
public class LaboratorioColecciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
 
        System.out.println("ArrayList: Exhibicion");
        ArrayList<Producto> listaExhibicion = new ArrayList<>();
        
        listaExhibicion.add(new Producto(1, "Teclado", "Perifericos"));
        listaExhibicion.add(new Producto(2, "Mouse", "Perifericos"));
        listaExhibicion.add(new Producto(3, "Monitor", "Pantallas"));
        listaExhibicion.add(new Producto(4, "Cable HDMI", "Oferta"));
        
        for (Producto producto : listaExhibicion) {
            System.out.println(producto);
        }
        
        
        System.out.println("\nLinkedList: Reabastecer");
        LinkedList<Producto> colaReabastecer = new LinkedList<>();
        
        colaReabastecer.addLast(new Producto(5, "Laptop", "Computo"));
        colaReabastecer.addFirst(new Producto(6, "Webcam", "Perifericos"));
        
        for (Producto producto : colaReabastecer) {
            System.out.println(producto);
        }
        
        System.out.println("\nHashSet: Categorias unicas");
        HashSet<String> categorias = new HashSet<>();
        
        categorias.add("Perifericos");
        categorias.add("Computo");
        categorias.add("Pantallas");
        categorias.add("Oferta");
        categorias.add("Perifericos"); 
        categorias.add("Computo");   
        
        System.out.println(categorias);
        
        System.out.println("\nHashMap: Consulta por id");
        HashMap<Integer, Producto> mapaPorId = new HashMap<>();
        
        for (Producto producto : listaExhibicion) {
            mapaPorId.put(producto.getId(), producto);
        }
        for (Producto producto : colaReabastecer) {
            mapaPorId.put(producto.getId(), producto);
        }
        
        Producto productoConsultado = mapaPorId.get(3);
        System.out.println("id=3 -> " + productoConsultado);
        System.out.println();
        
        System.out.println("Recorriendo HashMap (entrySet):");
        for (Map.Entry<Integer, Producto> entrada : mapaPorId.entrySet()) {
            System.out.println(entrada.getKey() + " -> " + entrada.getValue());
        }
        
        System.out.println("\nIterator: eliminar categoria 'Oferta' en listaExhibicion");
        
        Iterator<Producto> iterator = listaExhibicion.iterator();
        while (iterator.hasNext()) {
            Producto producto = iterator.next();
            if (producto.getCategoria().equals("Oferta")) {
                iterator.remove();
            }
        }
       
        System.out.println("Despues de eliminar:");
        for (Producto producto : listaExhibicion) {
            System.out.println(producto);
        }
    }
    
}
