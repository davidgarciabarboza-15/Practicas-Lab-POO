package animales;

public class Delfin extends Animal implements IAcuatico{

    public Delfin(String nombre) {
        super(nombre);
    }

    @Override
    public void hacerSonido() {
        System.out.println("Delfin hace sonido");
    }

    @Override
    public void nadar() {
        System.out.println("Delfin nadando");
    }
    
    public String respirar(){
        return "Delfin respirando";
    }
}
