package animales;

public class Aguila extends Animal implements IVolar{

    public Aguila(String nombre) {
        super(nombre);
    }

    @Override
    public void hacerSonido() {
        System.out.println("El Aguila hace un sonido");
    }

    @Override
    public void volar() {
        System.out.println("El Aguila vuela alto");
    }
    
    public void cazar(){
        System.out.println("El Aguila caza");
    }
    
    public String respirar(){
        return "El Aguila respira";
    }
}
