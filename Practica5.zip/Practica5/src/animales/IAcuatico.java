package animales;

public interface IAcuatico {
    
    void nadar();

    default int profundidadMax(){
        return 200;
    }
}