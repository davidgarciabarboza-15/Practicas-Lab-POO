package animales;

public interface IVolar {
    void volar();

    default int alturaMax(){
        return 300;
    }
}
