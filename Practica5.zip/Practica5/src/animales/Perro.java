package animales;

public class Perro extends Animal implements ITerrestre{

    public Perro(String nombre) {
        super(nombre);
    }

    @Override
    public void hacerSonido() {
        System.out.println("El perro ladra");
    }

    @Override
    public void caminar() {
        System.out.println("El Perro camina alegremente");
    }
    
    public String respirar(){
        return "El Perro respira";
    }
    
    public String jugar(){
        return "El perro juega";
    }
}
