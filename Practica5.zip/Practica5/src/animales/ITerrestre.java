package animales;

public interface ITerrestre {
    void caminar();
    
    default int velocidadMax(){
        return 20;
    }
}
