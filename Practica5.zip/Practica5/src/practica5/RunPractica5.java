package practica5;
import animales.*;
/**
 *
 * @author david
 */
public class RunPractica5 
{
    public static void main(String[] args) 
    {
        // TODO code application logic here
        Delfin d = new Delfin("flipper");
        Aguila a = new Aguila("Kevin");
        Perro p = new Perro("Firulais");
        
        String r;
        r = d.respirar();
        System.out.println(r); //System.out.println(d.respirar());
        
        d.despertar();
        d.hacerSonido();
        d.comer();
        d.nadar();
        System.out.println("La profunidad maxima es de: " + d.profundidadMax() + "\n");
        
        
        System.out.println(a.respirar());
        a.despertar();
        a.hacerSonido();
        a.cazar();
        a.comer();
        a.volar();
        System.out.println("La altura maxima es de: " + a.alturaMax() + "\n");
        
        
        System.out.println(p.respirar());
        p.despertar();
        System.out.println(p.jugar());
        p.hacerSonido();
        p.comer();
        p.caminar();
        System.out.println("La velocidad maxima es de: " + p.velocidadMax() + "\n");
    }
}
