package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EnviaDatos extends HttpServlet {

    // Configuración 
    private static final String DB_URL = "jdbc:mysql://localhost:3306/practica11POO?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Hornet_15"; //Aqui ya varia, esta es mi constraseña con usuario root y la url

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("fname");
        String apellido = request.getParameter("lname");
        String email = request.getParameter("email");
        String telefono = request.getParameter("phone");

        boolean guardadoExitoso = false;
        String mensajeError = "";

        if (nombre == null || nombre.trim().isEmpty() ||
            apellido == null || apellido.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            telefono == null || telefono.trim().isEmpty()) {
            mensajeError = "Todos los campos son obligatorios.";
        } else {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    String sql = "INSERT INTO Personas (nombre, apellido, email, telefono) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setString(1, nombre.trim());
                        stmt.setString(2, apellido.trim());
                        stmt.setString(3, email.trim());
                        stmt.setString(4, telefono.trim());
                        stmt.executeUpdate();
                        guardadoExitoso = true;
                    }
                }
            } catch (ClassNotFoundException e) {
                mensajeError = "Error: Controlador JDBC no encontrado.";
                e.printStackTrace();
            } catch (SQLException e) {
                mensajeError = "Error al guardar en la base de datos: " + e.getMessage();
                e.printStackTrace();
            }
        }

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Resultado del Registro</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; margin: 40px; background-color: #f9f9f9; }");
            out.println(".container { max-width: 600px; margin: auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }");
            out.println("h1 { color: #2c3e50; }");
            out.println(".success { color: green; }");
            out.println(".error { color: red; }");
            out.println("a { display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #3498db; color: white; text-decoration: none; border-radius: 4px; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class='container'>");

            if (guardadoExitoso) {
                out.println("<h1 class='success'> Registro guardado correctamente</h1>");
                out.println("<p><strong>Nombre:</strong> " + nombre + "</p>");
                out.println("<p><strong>Apellido:</strong> " + apellido + "</p>");
                out.println("<p><strong>Email:</strong> " + email + "</p>");
                out.println("<p><strong>Teléfono:</strong> " + telefono + "</p>");
            } else {
                out.println("<h1 class='error'> Error al guardar los datos</h1>");
                out.println("<p>" + mensajeError + "</p>");
            }

            out.println("<br><a href='index.html'>← Volver al formulario</a>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet que guarda datos en MySQL.";
    }
}