/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.agenda.web;

import com.ejemplo.agenda.model.Contacto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ejemplo.agenda.dao.ContactoDAOImpl;

/**
 *
 * @author david
 */
@WebServlet({"/contactos", "/"})
public class ContactoServlet extends HttpServlet {

    private final ContactoDAOImpl dao = new ContactoDAOImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("nuevo".equals(action)) {
            // Ir al formulario de nuevo contacto
            request.getRequestDispatcher("/views/form.jsp").forward(request, response);
        } else {
            // Mostrar lista de contactos
            List<Contacto> contactos = dao.listarTodos();
            request.setAttribute("contactos", contactos);
            request.getRequestDispatcher("/views/lista.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String nombre = request.getParameter("nombre");
        String apellidoPaterno = request.getParameter("apellidoPaterno");
        String apellidoMaterno = request.getParameter("apellidoMaterno");
        String sexo = request.getParameter("sexo");
        String telefono = request.getParameter("telefono");
        String direccion = request.getParameter("direccion");
        String tipoContacto = request.getParameter("tipoContacto");

        Contacto contacto = new Contacto();
        contacto.setNombre(nombre);
        contacto.setApellidoPaterno(apellidoPaterno);
        contacto.setApellidoMaterno(apellidoMaterno);
        contacto.setSexo(sexo);
        contacto.setTelefono(telefono);
        contacto.setDireccion(direccion);
        contacto.setTipoContacto(tipoContacto);

        dao.crear(contacto);

        response.sendRedirect("contactos");
    }
}