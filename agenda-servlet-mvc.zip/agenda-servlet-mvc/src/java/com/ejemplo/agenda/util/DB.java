/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.agenda.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author david
 */
public class DB {
    private static final String url = "jdbc:mysql://localhost:3306/agenda";
    private static final String usuario = "root"; 
    private static final String contrasenia = "Hornet_15"; //Esta es mi contraseña

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Driver de MySQL no encontrado", e);
        }
        return DriverManager.getConnection(url, usuario, contrasenia);
    }
}
