/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.agenda.dao;

import com.ejemplo.agenda.model.Contacto;
import java.util.List;

/**
 *
 * @author david
 */
public interface ContactoDAO {
    List<Contacto> listarTodos();

    void crear(Contacto contacto);
    
}
