/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.agenda.dao;
import com.ejemplo.agenda.model.Contacto;
import com.ejemplo.agenda.util.DB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author david
 */
public class ContactoDAOImpl implements ContactoDAO {

    @Override
    public List<Contacto> listarTodos() {
        List<Contacto> contactos = new ArrayList<>();
        String sql = "SELECT * FROM contactos ORDER BY id";

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Contacto contacto = new Contacto();
                contacto.setId(rs.getInt("id"));
                contacto.setNombre(rs.getString("nombre"));
                contacto.setApellidoPaterno(rs.getString("apellido_paterno"));
                contacto.setApellidoMaterno(rs.getString("apellido_materno"));
                contacto.setSexo(rs.getString("sexo"));
                contacto.setTelefono(rs.getString("telefono"));
                contacto.setDireccion(rs.getString("direccion"));
                contacto.setTipoContacto(rs.getString("tipo_contacto"));
                contactos.add(contacto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return contactos;
    }

    @Override
    public void crear(Contacto contacto) {
        String sql = "INSERT INTO contactos (nombre, apellido_paterno, apellido_materno, sexo, telefono, direccion, tipo_contacto) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, contacto.getNombre());
            stmt.setString(2, contacto.getApellidoPaterno());
            stmt.setString(3, contacto.getApellidoMaterno());
            stmt.setString(4, contacto.getSexo());
            stmt.setString(5, contacto.getTelefono());
            stmt.setString(6, contacto.getDireccion());
            stmt.setString(7, contacto.getTipoContacto());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}