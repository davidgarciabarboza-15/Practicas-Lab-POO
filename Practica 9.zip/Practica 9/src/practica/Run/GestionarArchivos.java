/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica.Run;
import java.io.*;
import java.util.Scanner;

/**
 *
 * @author david
 */
public class GestionarArchivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        File carpeta = new File("datos");
        
        if (!carpeta.exists()) {
            boolean carpetaCreada = carpeta.mkdir();
            if (carpetaCreada) {
                System.out.println("Carpeta 'datos' creada");
            }
        } else {
            System.out.println("Carpeta 'datos' ya existe");
        }

        File archivo = new File(carpeta, "productos.txt");
        
        System.out.println("\n=== Registro de productos ===");
        
        Scanner setup = new Scanner(System.in);
        BufferedWriter escritor = null;
        
        try {
            System.out.print("Cuantos productos quieres agregar?: ");
            int cantidad = setup.nextInt();
            setup.nextLine(); 

            escritor = new BufferedWriter(new FileWriter(archivo, true));
            
            for (int i = 1; i <= cantidad; i++) {
                System.out.println("\nProducto #" + i);
                System.out.print("ID: ");
               
                int id = setup.nextInt();
                setup.nextLine();
                
                System.out.print("Nombre: ");
                String nombre = setup.nextLine();
                
                System.out.print("Categoria: ");
                String categoria = setup.nextLine();
             
                escritor.write(id + "," + nombre + "," + categoria);
                escritor.newLine();
            }
            
            System.out.println("\nProductos guardados correctamente");
            
        } catch (IOException e) {
            System.err.println("Error al escribir: " + e.getMessage());
        } finally {
            if (escritor != null) {
                try {
                    escritor.close();
                } catch (IOException e) {
                    System.err.println("Error al cerrar escritor: " + e.getMessage());
                }
            }
        }
        
        System.out.println("\n=== Lectura del archivo ===");
        BufferedReader lector = null;
        try {
            lector = new BufferedReader(new FileReader(archivo));
            String linea;
       
            while ((linea = lector.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (IOException e) {
            System.err.println("Error al leer: " + e.getMessage());
        } finally {
            if (lector != null) {
                try {
                    lector.close();
                } catch (IOException e) {
                    System.err.println("Error al cerrar lector: " + e.getMessage());
                }
            }
        }

        System.out.println("\n=== Archivos en la carpeta 'datos' ===");
        String[] listaArchivos = carpeta.list();
        if (listaArchivos != null && listaArchivos.length > 0) {
            for (String nombreArchivo : listaArchivos) {
                System.out.println(nombreArchivo);
            }
        } else {
            System.out.println("No hay archivos en la carpeta 'datos'");
        }
        
        setup.close();
    }
    
}
