package practica.pkg2;
import Transporte.Automovil;
import Transporte.Carro;
/**
 *
 * @author david
 */
public class Practica2 
{
    public static void main(String[] args) 
    {
        //Automovil
        Automovil Tsuru = new Automovil("Nissan","Tsuru","RPG-015-A","4S3BMHB68B3286050",10);
        Tsuru.Automovil_info();
        if(Tsuru.cantidad() > 1)
        {
            Tsuru.MotorOn();
            Tsuru.Avanzar();
            Tsuru.Detener();
            Tsuru.MotorOff();
        }
        else
            Tsuru.Gasolina();
        
        System.out.println("");
        
        //Carro
        Carro coche = new Carro();
        coche.setMarca("Tesla");
        coche.setModelo("CyberTruck");
        coche.setPlaca("JPG-020-C");
        coche.setNumserie("7f3BKPX61B9986010");
        coche.setGasolina(0);
        System.out.println("Marca: " + coche.getMarca() + ", Modelo: " + coche.getModelo() 
                            + ", Placa: " + coche.getPlaca() + ", Numero de serie: " + coche.getNumserie() + ", Litros de gasolina: " + 
                            coche.getGasolina() );
        if(coche.getGasolina() > 1)
        {
            coche.encender();
            System.out.println(coche.avanzar());
            System.out.println(coche.detenerse());
        }    
        else
            System.out.println(coche.gasolina());
    }
}
