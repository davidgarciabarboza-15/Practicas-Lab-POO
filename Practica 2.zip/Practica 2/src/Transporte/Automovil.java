package Transporte;
/**
 *
 * @author david
 */
public class Automovil {
    
    private String marca;
    private String modelo;
    private String placa;
    private String numserie;
    private int gasolina;
    
    public Automovil(String marca, String modelo, String placa, String numserie, int gasolina){
    this.marca = marca;
    this.modelo = modelo;
    this.placa = placa;
    this.numserie = numserie;
    this.gasolina = gasolina;
    }
    
    public void Automovil_info(){
        System.out.println("Marca: " + marca + ", Modelo: " + modelo + ", Placa: " + placa + ", Numero de serie: " + numserie
                            + ", Litros de gasolina: " + gasolina);
    }
    
    public void MotorOn(){
        System.out.println("Motor encendido");
    }
    
    public void MotorOff(){
        System.out.println("Motor apagado");
    }
    
    public void Avanzar(){
        System.out.println("Avanzar hacia el frente");
    }
    
    public void Detener(){
        System.out.println("Detener el coche");
    }
    
    public int cantidad(){
        return this.gasolina;
    }
    
    public void Gasolina(){
        System.out.println("No hay gasolina, no se puede avanzar");
    }
    
}

