package Transporte;
/**
 *
 * @author david
 */
public class Carro 
{

    /**
     * @return the gasolina
     */
    public int getGasolina() {
        return gasolina;
    }

    /**
     * @param gasolina the gasolina to set
     */
    public void setGasolina(int gasolina) {
        this.gasolina = gasolina;
    }

    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    /**
     * @return the numserie
     */
    public String getNumserie() {
        return numserie;
    }

    /**
     * @param numserie the numserie to set
     */
    public void setNumserie(String numserie) {
        this.numserie = numserie;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    private String marca;
    private String modelo;
    private String placa;
    private String numserie;
    private int gasolina;
    
    
    public void encender()
    {
        System.out.println("Motor prendido");
    
    }
    
    public String avanzar()
    {
        return "Avanzar hacia adelante";
    }
    
    public String detenerse()
    {
        return "Detener el carro";
    }
    
    public String gasolina()
    {
        return "No hay gasolina, no se puede avanzar";
    }
    
}



