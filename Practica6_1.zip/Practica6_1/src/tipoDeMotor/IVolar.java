/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package tipoDeMotor;

/**
 *
 * @author david
 */
public interface IVolar {
    
    void despegar();
    void aterrizar();
    default void volar(int altura) {
        System.out.println("Volando a " + altura + " metros de altura");
    }
    
}