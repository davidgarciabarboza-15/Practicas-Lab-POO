/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import tipoDeMotor.ICombustion;
import transporte.Vehiculo;

/**
 *
 * @author david
 */
public class AutoCombustion extends Vehiculo implements ICombustion {
    
    public AutoCombustion(String marca, String modelo, double velocidad){
        super(marca, modelo, velocidad);
    }
    
    @Override
    public void cargarGas(double litrosGas) {
        System.out.println("Cargando " + litrosGas + " litros de gasolina");
    }
    
    @Override
    public String tipo() {
        return "Auto de combustion";
    }
}
