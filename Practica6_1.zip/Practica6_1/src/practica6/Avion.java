/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import tipoDeMotor.IVolar;
import transporte.Vehiculo;

/**
 *
 * @author david
 */
public class Avion extends Vehiculo implements IVolar {
    
    private boolean enVuelo;
    
    public Avion(String marca, String modelo, double velocidad){
        super(marca, modelo, velocidad);
        this.enVuelo = false;
    }
    
    @Override
    public void despegar() {
        if (!enVuelo) {
            System.out.println("Despegando\nEl avion a despegado");
            enVuelo = true;
        } else {
            System.out.println("El avion ya esta en vuelo");
        }
    }
    
    @Override
    public void aterrizar() {
        if (enVuelo) {
            System.out.println("Aterrizando\nEl avion a aterrizado");
            enVuelo = false;
        } else {
            System.out.println("El avion ya esta en tierra");
        }
    }
    
    @Override
    public void volar(int altura) {
        if (enVuelo) {
            System.out.println("Volando a " + altura + " metros de altura con el avion " + marca);
        } else {
            System.out.println("Primero debe despegar el avion");
        }
    }
    
    @Override
    public String tipo() {
        return "Avion comercial";
    }
    
    // Método específico de Avion
    public void activarTrenAterrizaje() {
        if (enVuelo) {
            System.out.println("Activando tren de aterrizaje para aterrizar");
        } else {
            System.out.println("Tren de aterrizaje ya extendido");
        }
    }
}
