/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica6;
//import java.lang.reflect.Array;
import java.util.*;
import transporte.*;
import tipoDeMotor.*;

/**
 *
 * @author david
 */
public class RunPractica6 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        VHibrido b = new VHibrido("byd", "dolphin", 30.00);
        
        Vehiculo g = new VHibrido("byd", "dolphin", 30.00);
        AutoCombustion c = new AutoCombustion("Nissan", "Tsuru", 0);
        AutoElectrico e = new AutoElectrico("Tesla", "CyberTruck", 0);
        Avion a = new Avion("Boeing", "840", 900.00);
        
        List<Vehiculo> flota = Arrays.asList(c, b, g, e, a);
        
        
        for(Vehiculo v:flota)
        {
            System.out.println("\n" + v.tipo());
            System.out.println("Marca: " + v.marca + ", Modelo: " + v.modelo);
            System.out.println("Velocidad inicial: " + v.getVelocidad());
            v.acelerar();
            System.out.println("Velocidad despues de acelerar: " + v.getVelocidad());
            
            // Llamadas polimórficas a métodos específicos
            if(v instanceof ICombustion) {
                ((ICombustion) v).cargarGas(50);
            }
            if(v instanceof IElectrico) {
                ((IElectrico) v).cargar(30);
            }
            if(v instanceof IVolar) {
                ((IVolar) v).despegar();
                ((IVolar) v).volar(10000);
                ((IVolar) v).aterrizar();
            }
        }
        
    }
    
}