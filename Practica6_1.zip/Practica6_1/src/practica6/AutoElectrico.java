/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import tipoDeMotor.IElectrico;
import transporte.Vehiculo;

/**
 *
 * @author david
 */
public class AutoElectrico extends Vehiculo implements IElectrico {
    
    public AutoElectrico(String marca, String modelo, double velocidad){
        super(marca, modelo, velocidad);
    }
    
    @Override
    public void cargar(double KWh) {
        System.out.println("Cargando " + KWh + " KWh de electricidad");
    }
    
    @Override
    public String tipo() {
        return "Auto electrico";
    }
}
