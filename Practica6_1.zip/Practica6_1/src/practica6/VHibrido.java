/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import tipoDeMotor.ICombustion;
import tipoDeMotor.IElectrico;
import transporte.Vehiculo;

/**
 *
 * @author david
 */
public class VHibrido extends Vehiculo implements IElectrico, ICombustion
{

    public VHibrido(String marca, String modelo, double velocidad){
        super(marca, modelo, velocidad);
    }
    
    @Override
    public void cargar(double KWh) {
        System.out.println("Cargando " + KWh + " KWh de electricidad (modo hibrido)");
    }

    @Override
    public void cargarGas(double litrosGas) {
        System.out.println("Cargando " + litrosGas + " litros de gasolina (modo hibrido)");
    }

    @Override
    public String tipo() {
        return "Auto hibrido";
    }
    
}